<div class="ctn">
	<div class="base">
		<form action="algo.php" method="post">
        <label>Folio</label> 
        <input type="text" name="folio">
        <label>Nombre del cliente</label>
            <input type="text" name="folio">
            <button type="submit" name="submit">Buscar</button>
  </form>

	</div>
    <div class="centro">
            <table>
             <tr>
                <td><p>Folio</p></td>
                <td><p>Cliente</p></td>
                <td><p>Fecha</p></td>
                <td><p>Monto</p></td>
                <td></td>
             </tr>
             <!--Termina la cabecera-->
              <tr>
                <td><p>Folio</p></td>
                <td><p>Cliente</p></td>
                <td><p>Fecha</p></td>
                <td><p>Monto</p></td>
                <td>eliminar </td>
             </tr>
                
            </table>
          
    </div>
    <div class="footer">
         <table>	
               <tr>
               	<td>Tipo de pago</td>
               	<td>Monto</td>
               </tr>
               <tr>
               	<td>Efectivo</td>
               	<td>$1052</td>
               </tr>
               <tr>
               	<td>Tarjeta de credito</td>
               	<td>$15600</td>
               </tr>
               <tr>
               	<td>Total</td>
               	<td>$15600</td>
               </tr>

         </table>
             <button type="submit" name="submit">Finalizar</button>
    </div>
</div>
