


         <nav>
             <ul>
              <li><a href="#"><span>Nueva Venta</span></a></li>
              <li><a href="#"><span>Cerrar  Venta</span></a></li>
              <li><a href="#"><span>devoluciones</span></a></li>
              <li><a href="#"><span>Pagos</span></a></li>
             </ul>  
         </nav>