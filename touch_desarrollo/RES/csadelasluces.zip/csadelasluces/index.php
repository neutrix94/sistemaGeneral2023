<?php require ("includes/header.php");?>
<?php require ("includes/menu.php");?>

  <?php require ("includes/contenido.php");?>

<?php require ("includes/footer.php");?>

        