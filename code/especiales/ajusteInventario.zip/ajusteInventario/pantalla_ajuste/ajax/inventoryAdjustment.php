<?php

	class inventoryAdjustment
	{
		private $link;
		private $store_id;
		function __construct( $connection, $store_id )
		{
			$this->link = $connection;
			$this->store_id = $store_id;
		}
		
		public function getStoreWharehouses( $warehouse_id = null ){
			$sql = "SELECT
						id_almacen AS id,
						nombre AS name
					FROM ec_almacen
					WHERE IF( '{$this->store_id}' = '-1',
							id_sucursal > 0,
							id_sucursal = {$this->store_id} )";
			$stm = $this->link->query( $sql ) or die( "Error al consultar almacenes de sucursal : {$this->link->error}" );
			$disabled = ( $warehouse_id != null ? 'disabled'  : '' );
			$resp = "<select id=\"warehouse_id\" class=\"form-control\" {$disabled}>";
				$resp .= "<option value=\"0\">-- Seleccionar Almacén --</option>";
			while ( $row = $stm->fetch_assoc() ) {
				$selected = ( $warehouse_id == $row['id'] ? 'selected' : '' );
				$resp .= "<option value=\"{$row['id']}\" {$selected}>{$row['name']}</option>";
			}
			$resp .= "</select>"; 
			return $resp;
		}
	
	}

?>