	
	function show_emergent_transfers_add( transfer_folio ){
	//	alert( transfer_folio );
		var url = "ajax/db.php?fl=getMessageToAddTransfer&transfers=" + current_transfers;
		url += "&transfer_to_add=" + transfer_folio;
		var response = ajaxR( url );
		//alert( response );
		$( '.emergent_content' ).html( response );
		$( '.emergent' ).css( 'display', 'block' );
	}

	function validateGroups(){
		var resp = true;
		$( '#transfers_list_content tr' ).each( function( index ){
			if( $( '#validation_list_8_' + index ).prop( 'checked' ) == true 
				&& $( '#validation_list_9_' + index ).hasClass( 'btn-warning' ) == true ){
				resp = false;
				return false;
			}
		});
		return resp;
	}

/**Funciones de bloque de transferencias**/
	function getAllGroup( counter ){
		var val = 1;
		if( global_current_transfer_destinity == '' ){
			global_current_transfer_destinity = $( '#validation_list_4_' + counter ).html().trim();
		}else{
			if( global_current_transfer_destinity != $( '#validation_list_4_' + counter ).html().trim() ){
				alert( "Las transferencias por validar deben de ser de la misma sucursal " );
				if( $( '#validation_list_8_' + counter ).prop( 'checked' ) ){
					 $( '#validation_list_8_' + counter ).removeAttr( 'checked' );
				}
			}
		}
		var block = $( '#validation_list_6_' + counter ).html().trim();
		if( ! $( '#validation_list_8_' + counter ).prop( 'checked' ) ){
			val = 0;
		}
		$( '#transfers_list_content tr' ).each( function( index ){
			if( $( '#validation_list_6_' + index ).html().trim() == block && block != '' ){
				if( val == 1 ){
					$( '#validation_list_8_' + index ).prop( 'checked', true );
				}else{
					$( '#validation_list_8_' + index ).removeAttr( 'checked', true );
				}
			}
		});
	//verifica si ningún check esta checado
		var without_sucursal = 0;
		$( '#transfers_list_content tr' ).each( function( index ){
			if( $( '#validation_list_8_' + index ).prop( 'checked' ) ){
				without_sucursal ++;
			}
		});
		if( without_sucursal == 0 ){
			global_current_transfer_destinity = '';
		}
	}

	function remove_transfer_group( transfer_id ){
		global_remove_transfer_id = transfer_id;
		var remove_all_validation = 0;
		if( $( '#current_transfers_sets tr' ).length <= 1 ){
			remove_all_validation = 1;	
		}
		var url = "ajax/db.php?fl=getPreviousRemoveTransferToValidation&transfer_id=" + transfer_id + "&reset_unic_transfer";
		if( remove_all_validation == 1 ){
			url += "&reset_unic_transfer=1";
		}
		var response = ajaxR( url );
		lock_and_unlock_focus( '#barcode_seeker_lock_btn', '#barcode_seeker', 'lock' );
		$( '.emergent_content' ).html( response );
		$( '.emergent' ).css( 'display', 'block' );
		
		if( remove_all_validation == 1 )
			$( '#manager_password' ).focus();
	}

	function confirm_remove_transfer_block(){
		var pss = $( '#manager_password' ).val();
		if( pss.length <= 0 ){
			alert( "La contraseña del encargado no puede ir vacía!" );
			$( '#manager_password' ).focus();
			return false;
		}
		var url = 'ajax/db.php?fl=validateManagerPassword&pass=' + pss;
		var response = ajaxR( url );
		if( response != 'ok' ){
			alert( response );
			/*$( '#response_password' ).html( response );
			$( '#response_password' ).css( 'display', 'block' );*/
		 	$( '#manager_password' ).select();
			return true;
		}
		url = "ajax/db.php?fl=removeTransferBlock&transfer_id=" + global_remove_transfer_id ;
		response = ajaxR( url );
		$( '.emergent_content' ).html( response );
		$( '.emergent' ).css( 'display', 'block' );
	}

	function removeTransferBlockDetail( transfer_product_id ){
		var url = "ajax/db.php?fl=removeTransferBlockDetail&transfer_id=" + global_remove_transfer_id;
			url += "&transfer_product_id=" + transfer_product_id;
		response = ajaxR( url );
		/*if( response!= 'ok' ){
			alert( response );
			return false;
		}else{*/
			$( '#detail_' + transfer_product_id ).remove();
			$( '.emergent_content_2' ).html( response );
			$( '.emergent_2' ).css( 'display', 'block' );
		//}
	}

	function option_add_transfer_validation( transfer_id ){
		var same_group = '', different_group = '';
	//verifica palabra en el primer campo
		same_group = $( '#together_option' ).val().trim();
		if( same_group != '' ){
			if( same_group.toUpperCase() != 'JUNTO' ){
				alert( `${same_group} no es una opcion valida, verifique y vuelva a intentar` );
				$( '#together_option' ).select();
				return false;
			}
			addTransferBlock( transfer_id );
			return true;
		}
	//verifica palabra en el segundo campo
		different_group = $( '#separate_option' ).val().trim();
		if( different_group != '' ){
			if( different_group.toUpperCase() != 'SEPARADO' ){
				alert( `${different_group} no es una opcion valida, verifique y vuelva a intentar` );
				$( '#separate_option' ).select();
				return false;
			}
			createBlock( transfer_id );
			return true;
		}
	}

	function createBlock( transfer_id = null ){
		var url = "ajax/db.php?fl=makeTransfersGroup&";
		if( transfer_id == null ){
			url += "transfers=" + current_transfers;
		}else{
			url += "transfers=" + transfer_id;
		}
		var response = ajaxR( url ).split( '|' );
		if( response[0] != 'ok' ){
			alert( "Error : " + response[0] );
			return false;
		}
		//alert( response[0] + ' - ' + response[1]  );
		//alert( current_transfers_blocks.includes( response[1] ) );
		if(  ! current_transfers_blocks.includes( response[1] ) && response[1] != '' ){// && transfer_id != null
			//alert( 'here_2' );
			current_transfers_blocks.push( response[1] );
		}
		if( transfer_id != null	 ){
			close_emergent();
		}
		reload_transfers_list_view();
		
	}

	function addTransferBlock( transfer_id ){
		var url = "ajax/db.php?fl=addTransferBlock&transfer=" + transfer_id;
		url += "&block_id=" + current_transfers_blocks[0];
		var response = ajaxR( url );
		if( response != 'ok' ){
			alert( response );
		}else{
			alert( "Transferencia agregada al bloque exitosamente." );
			close_emergent();
			current_transfers.push( transfer_id );
		}
		reload_transfers_list_view();
		//alert( url );
	}
