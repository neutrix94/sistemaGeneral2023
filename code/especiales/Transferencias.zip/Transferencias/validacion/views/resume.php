<?php

?>
	<div class="resume_content">
		<div class="group_card adjustments differences">
		</div>

<hr>
		<div class="group_card adjustments aggregates">
		</div>
		<div class="row">
			<div class="col-2"></div>
			<div class="col-8">
				<!--button
					type="button"
					class="btn btn-success form-control"
					onclick="finish_validation();"
				>
					Finalizar Revisión
				</button-->
			</div>
			<div class="col-2"></div>
		</div>
	</div>