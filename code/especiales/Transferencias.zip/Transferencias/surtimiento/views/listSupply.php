
<br />
<table class="table table-bordered table-striped" style="margin : 10px; width : calc( 100% - 20px ); font-size : 80%;">
	<thead class="header_sticky-0">
		<tr>
			<th>Producto</th>
			<th>Modelo</th>
			<th>Cajas</th>
			<th>Paq</th>
			<th>Pzs</th>
			<th>Tot Pzs</th>
		</tr>
	</thead>
	<tbody id="list_assignmets_supplied">
	<?php
		//echo getAssignmentList( $user_id, $link );
	?> 
	</tbody>
</table>